package com.mjmr.lgp

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
 private lateinit var status: TextView
 private lateinit var counts: TextView
 private val prefs by lazy { getSharedPreferences("lgp", MODE_PRIVATE) }
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }
 override fun onResume() { super.onResume(); if (::status.isInitialized) refresh() }
 private fun label(s: String, size: Float = 17f): TextView = TextView(this).apply { text=s; textSize=size; setTextColor(Color.WHITE); setPadding(14,14,14,14) }
 private fun render() {
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,35,22,20); setBackgroundColor(Color.rgb(18,10,35)) }
  val scroll=ScrollView(this).apply { addView(root) }; setContentView(scroll)
  root.addView(label("♛ MJMR LGP+",32f)); root.addView(label("LOCAL GUARDIAN PROTOCOL • DNS PRIVACY",14f))
  status=label("",22f); root.addView(status)
  counts=label(""); root.addView(counts)
  val start=Button(this).apply { text="ENABLE PROTECTION"; setOnClickListener { val request=VpnService.prepare(this@MainActivity); if(request!=null) startActivityForResult(request,1) else startVpn() } }; root.addView(start)
  root.addView(Button(this).apply { text="DISABLE PROTECTION"; setOnClickListener { startService(Intent(this@MainActivity,DnsVpnService::class.java).setAction("STOP")); refresh() } })
  root.addView(label("FILTERS • LOCAL DNS BLOCKLIST",19f))
  root.addView(label("Block advertising and tracking domains using a local list. No browsing history is uploaded by this app." ,14f))
  val edit=EditText(this).apply { setText(prefs.getString("domains", DEFAULT_DOMAINS)); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); minLines=7; gravity=Gravity.TOP; hint="One domain per line" }; root.addView(edit)
  root.addView(Button(this).apply { text="SAVE BLOCKLIST"; setOnClickListener { prefs.edit().putString("domains",edit.text.toString()).apply(); Toast.makeText(this@MainActivity,"Saved. Restart protection to apply.",Toast.LENGTH_LONG).show() } })
  root.addView(label("ACTIVITY LOG • LOCAL COUNTS",19f))
  root.addView(Button(this).apply { text="REFRESH COUNTS"; setOnClickListener { refresh() } })
  root.addView(label("LIMITS: DNS-only IPv4 UDP filtering. It does not inspect HTTPS content, remove visual ad elements, filter encrypted DNS, or block every in-app advert. Other VPNs cannot run simultaneously.",13f))
  refresh()
 }
 private fun refresh(){ status.text=if(DnsVpnService.running) "● PROTECTION ACTIVE" else "○ PROTECTION OFF"; counts.text="Blocked DNS queries: ${prefs.getLong("blocked",0)}   •   Forwarded: ${prefs.getLong("forwarded",0)}" }
 private fun startVpn(){ startForegroundService(Intent(this,DnsVpnService::class.java).setAction("START")); status.postDelayed({ refresh() },500) }
 @Deprecated("Android VPN consent result") override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==1&&resultCode==RESULT_OK) startVpn()}
 companion object { const val DEFAULT_DOMAINS="doubleclick.net\ngooglesyndication.com\ngoogleadservices.com\napp-measurement.com\nfacebook.com.invalid\nadnxs.com\nscorecardresearch.com" }
}
