package com.mjmr.lgp

import android.app.*
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/** Minimal, user-controlled IPv4 UDP/53 DNS VPN. Not a full traffic VPN or security product. */
class DnsVpnService : VpnService() {
 private var tunnel: ParcelFileDescriptor?=null
 private var worker: Thread?=null
 private val active=AtomicBoolean(false)
 override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)
 override fun onStartCommand(intent: Intent?, flags:Int, startId:Int):Int {
  if(intent?.action=="STOP") { shutdown(); stopSelf(); return START_NOT_STICKY }
  if(active.get()) return START_STICKY
  val channel="lgp_dns"
  (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(channel,"LGP+ DNS protection",NotificationManager.IMPORTANCE_LOW))
  val notification=Notification.Builder(this,channel).setContentTitle("MJMR LGP+ DNS filtering").setContentText("DNS filtering active • tap to open").setSmallIcon(android.R.drawable.ic_lock_lock)
   .setContentIntent(PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE)).build()
  startForeground(12,notification)
  try {
   tunnel=Builder().setSession("MJMR LGP+ DNS").addAddress("10.77.0.2",32).addDnsServer("10.77.0.1").addRoute("10.77.0.1",32).setMtu(1500).establish()
   if(tunnel==null) { stopSelf(); return START_NOT_STICKY }
   active.set(true); running=true
   worker=Thread { loop() }.also { it.start() }
  } catch(e:Exception) { shutdown(); stopSelf() }
  return START_STICKY
 }
 private fun loop() {
  val fd=tunnel ?: return
  val input=FileInputStream(fd.fileDescriptor); val output=FileOutputStream(fd.fileDescriptor)
  val prefs=getSharedPreferences("lgp",MODE_PRIVATE)
  val blocked=prefs.getString("domains",MainActivity.DEFAULT_DOMAINS).orEmpty().lines().map { it.trim().lowercase() }.filter { it.isNotEmpty() && !it.startsWith("#") }.toSet()
  val upstream=InetAddress.getByName("1.1.1.1")
  val buffer=ByteArray(32767)
  while(active.get()) try {
   val n=input.read(buffer); if(n<29) continue
   val version=(buffer[0].toInt() ushr 4); val ihl=(buffer[0].toInt() and 15)*4
   if(version!=4 || ihl<20 || n<ihl+8 || (buffer[9].toInt() and 255)!=17) continue
   val srcPort=u16(buffer,ihl); val dstPort=u16(buffer,ihl+2)
   if(dstPort!=53) continue
   val dnsOffset=ihl+8; val dnsLen=n-dnsOffset
   if(dnsLen<12) continue
   val query=buffer.copyOfRange(dnsOffset,n)
   val name=domain(query)
   val deny=name!=null && blocked.any { name==it || name.endsWith(".$it") }
   val response=if(deny) {
    prefs.edit().putLong("blocked",prefs.getLong("blocked",0)+1).apply()
    query.copyOf().apply { this[2]=(this[2].toInt() or 0x80).toByte(); this[3]=((this[3].toInt() and 0xf0) or 3).toByte(); this[6]=0;this[7]=0;this[8]=0;this[9]=0;this[10]=0;this[11]=0 }
   } else {
    val answer=try { DatagramSocket().use { socket -> protect(socket); socket.soTimeout=2500; socket.send(DatagramPacket(query,query.size,upstream,53)); val received=ByteArray(4096); val packet=DatagramPacket(received,received.size); socket.receive(packet); received.copyOf(packet.length) } } catch (_:Exception) { null }
    if(answer!=null) prefs.edit().putLong("forwarded",prefs.getLong("forwarded",0)+1).apply()
    answer
   } ?: continue
   val packet=makeResponse(buffer,ihl,srcPort,response)
   output.write(packet)
  } catch (_:Exception) { if(!active.get()) break }
 }
 private fun domain(q:ByteArray):String? { var p=12; val parts=mutableListOf<String>(); var steps=0
  while(p<q.size && steps++<64) { val len=q[p].toInt() and 255; p++; if(len==0) return parts.joinToString(".").lowercase(); if(len>63||p+len>q.size) return null; parts.add(String(q,p,len,Charsets.US_ASCII));p+=len };return null }
 private fun u16(a:ByteArray,p:Int)=((a[p].toInt() and 255) shl 8) or (a[p+1].toInt() and 255)
 private fun put16(a:ByteArray,p:Int,v:Int){a[p]=(v ushr 8).toByte();a[p+1]=v.toByte()}
 private fun checksum(a:ByteArray,start:Int,len:Int):Int { var sum=0L;var p=start;val end=start+len;while(p+1<end){sum+=u16(a,p);p+=2};if(p<end)sum+=(a[p].toInt() and 255) shl 8;while(sum>65535)sum=(sum and 65535)+(sum ushr 16);return (sum.toInt() xor 65535) and 65535 }
 private fun makeResponse(request:ByteArray,ihl:Int,clientPort:Int,dns:ByteArray):ByteArray {
  val size=20+8+dns.size; val out=ByteArray(size)
  out[0]=0x45;out[1]=0;put16(out,2,size);put16(out,4,u16(request,4));put16(out,6,0);out[8]=64;out[9]=17
  System.arraycopy(request,16,out,12,4);System.arraycopy(request,12,out,16,4)
  put16(out,20,53);put16(out,22,clientPort);put16(out,24,8+dns.size)
  System.arraycopy(dns,0,out,28,dns.size)
  put16(out,10,checksum(out,0,20))
  // UDP checksum with IPv4 pseudo-header; zero checksum is legal for IPv4 UDP, but compute it.
  val pseudo=ByteArray(12+8+dns.size)
  System.arraycopy(out,12,pseudo,0,8);pseudo[8]=0;pseudo[9]=17;put16(pseudo,10,8+dns.size)
  System.arraycopy(out,20,pseudo,12,8+dns.size)
  val sum=checksum(pseudo,0,pseudo.size);put16(out,26,if(sum==0)65535 else sum)
  return out
 }
 private fun shutdown(){ active.set(false);running=false;try{tunnel?.close()}catch(_:Exception){};tunnel=null;worker=null;stopForeground(STOP_FOREGROUND_REMOVE) }
 override fun onDestroy(){shutdown();super.onDestroy()}
 override fun onRevoke(){shutdown();stopSelf();super.onRevoke()}
 companion object { @Volatile var running=false }
}
